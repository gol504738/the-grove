var express = require('express');
var router = express.Router();

/* GET play page. */
router.get('/:debug(debug)?', function(req, res, next) {
  if (!req.params.debug) {
    res.render('play', {
      title: 'Play | The Grove™'
    });
  }
  else {
    res.send('debugging');
  }
  next();
});

module.exports = router;