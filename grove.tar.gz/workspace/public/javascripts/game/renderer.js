update = function() {
    window.requestAnimationFrame(update);
    ctx.clearRect(0, 0, WIDTH*2, HEIGHT*2);
    if (!paused) {
        frameCount++;
        score++;

        currentMap.draw()
        if (frameCount % 100 === 0) //every 4 sec
            randomlyGenerateSlime();
        if (frameCount % 300 === 0)
            randomlyGenerateGoblin();
        if (frameCount % 500 === 0)
            randomlyGenerateGooshroom();
        if (frameCount % 1000 === 0)
            randomlyGenerateTank();
        if (frameCount % 75 === 0) //every 3 sec
            randomlyGenerateUpgrade();

        player.attackCounter += player.atkSpd;
        player.updatePosition()

        for (var key in bulletList) {
            bulletList[key].update();

            var toRemove = false;
            bulletList[key].timer++;
            if (bulletList[key].timer > 75) {
                toRemove = true;
            }
            if (bulletList[key].combatType == "enemy") {
                if (bulletList[key].testCollision(player)) {
                    player.hp = player.hp - bulletList[key].atk
                    console.log("player hit")
                    toRemove = true;
                }
            }
            if (bulletList[key].combatType == "player") {
                for (var key2 in enemyList) {
                    if (bulletList[key].testCollision(enemyList[key2])) {
                        toRemove = true;
                        enemyList[key2].hp -= player.bltAtk
                        break;
                    }
                }
            }
            if (toRemove) {
                delete bulletList[key];
            }
        }

        for (var key in upgradeList) {
            upgradeList[key].update();
            var isColliding = player.testCollision(upgradeList[key]);
            if (isColliding) {
                if (upgradeList[key].category === 'score')
                    score += 1000;
                if (upgradeList[key].category === 'atkSpd')
                    player.hp++;
                delete upgradeList[key];
            }
        }

        for (var key in enemyList) {
            enemyList[key].update();
            enemyList[key].attackCounter += enemyList[key].atkSpd
            enemyList[key].performAttack();

            var isColliding = player.testCollision(enemyList[key]);
            if (isColliding) {
                player.hp -= enemyList[key].atk
            }
            if (enemyList[key].hp <= 0) {
                delete enemyList[key]
            }
        }
        if (player.hp <= 0) {
            var timeSurvived = Date.now() - timeWhenGameStarted;
            $("#log").prepend("<h3>You lost! You got " + score + " points in " + timeSurvived + " ms.</h2>");
            startNewGame();
        }
        player.update();
        ctx.fillStyle = "red"
        ctx.fillRect(5, window.innerHeight - 30, player.hp * 30, 20);
        ctx.fillStyle = "green"
        ctx.fillRect(window.innerWidth / 2 + 40, window.innerHeight - 30, player.attackCounter * 2.5, 20);
    }
    else {
        ctx.fillStyle = "white"
        ctx.font = "50px Arial"
        ctx.fillText("PAUSED", WIDTH / 2 - 50, HEIGHT / 2 + 25)
    }
}