var ctx = document.getElementById("ctx").getContext("2d");
ctx.font = '200px Arial';
var paused = false;

var HEIGHT = 600;
var WIDTH = 1360;
document.getElementById("ctx").setAttribute("width", window.innerWidth)
document.getElementById("ctx").setAttribute("height", window.innerHeight)
var timeWhenGameStarted = Date.now(); //return time in ms

var frameCount = 0;

var score = 0;
var player;

Entity = function(type, id, x, y, width, height, img) {
	var self = {
		type: type,
		x: x,
		y: y,
		width: width,
		height: height,
		img: img,
	};
	self.update = function() {
		self.updatePosition()
		self.draw();
	}
	self.getDistance = function(entity2) { //return distance (number)
		var vx = self.x - entity2.x;
		var vy = self.y - entity2.y;
		return Math.sqrt(vx * vx + vy * vy);
	}
	self.testCollision = function(entity2) { //return if colliding (true/false)
		var rect1 = {
			x: self.x - self.width / 2,
			y: self.y - self.height / 2,
			width: self.width,
			height: self.height,
		}
		var rect2 = {
			x: entity2.x - entity2.width / 2,
			y: entity2.y - entity2.height / 2,
			width: entity2.width,
			height: entity2.height,
		}
		return testCollisionRectRect(rect1, rect2);
	}

	self.updatePosition = function() {

	}

	self.draw = function() {
		ctx.save();

		var x = self.x - player.x
		var y = self.y - player.y

		x += WIDTH / 2
		y += HEIGHT / 2

		x -= self.width / 2
		y -= self.height / 2

		x -= self.width / 2
		y -= self.height / 2

		ctx.drawImage(self.img, 0, 0, self.img.width, self.img.height, x, y, self.width, self.height)
		if (self.type == "enemy") {
			var w = self.width * self.hp / self.m
			if (w < 0) w = 0
			ctx.fillStyle = "red"
			ctx.fillRect(x, y - 15, w, 10)
			ctx.strokeStyle = "black"
			ctx.strokeRect(x, y - 15, self.width, 10)
		}
		ctx.restore()
	}

	return self;
}

Actor = function(type, id, x, y, width, height, img, hp, atk, bulletAtk) {
	var self = Entity(type, id, x, y, width, height, img);

	self.attackCounter = 0;
	self.aimAngle = 0;
	self.atkSpd = 1;
	self.hp = hp
	self.m = hp
	self.atk = atk
	self.bltAtk = bulletAtk

	self.performAttack = function(aimoverride) {
		if (self.attackCounter > 25) { //every 1 sec
			self.attackCounter -= 25;
			generateBullet(self, aimoverride);
		}
	}
	self.performSpecialAttack = function() {
		if (self.attackCounter > 50) { //every 1 sec
			self.attackCounter -= 50;

			for (var i = 0; i < 10; i++) {
				generateBullet(self, i * 36);
			}

			/*generateBullet(self,self.aimAngle - 5);
			generateBullet(self,self.aimAngle);
			generateBullet(self,self.aimAngle + 5);*/
		}
	}
	if (self.type == "enemy") {
		self.updateAim = function() {
			var diffX = player.x - self.x
			var diffY = player.y - self.y
			self.aimAngle = Math.atan2(diffY, diffX) / Math.PI * 180
		}

		self.updatePosition = function() {
			var diffX = player.x - self.x
			var diffY = player.y - self.y

			if (diffX > 0)
				self.x += 1.5
			else
				self.x -= 1.5
			if (diffY > 0)
				self.y += 1.5
			else
				self.y -= 1.5
		}
	}
	return self;
}


Player = function() {
	var p = Actor('player', 'myId', 50, 40, 40, 70, Img.player, 20, 5, 2);
	p.bltImg = Img.bullet.rock
	p.updatePosition = function() {
		if (p.pressingRight)
			p.x += 6;
		if (p.pressingLeft)
			p.x -= 6;
		if (p.pressingDown)
			p.y += 6;
		if (p.pressingUp)
			p.y -= 6;

		//is position valid
		if (p.x < p.width)
			p.x = p.width;
		if (p.x > currentMap.width)
			p.x = currentMap.width;
		if (p.y < p.height)
			p.y = p.height;
		if (p.y > currentMap.height)
			p.y = currentMap.height;
	}

	p.pressingDown = false;
	p.pressingUp = false;
	p.pressingLeft = false;
	p.pressingRight = false;
	return p;
}

var enemyList = {};
var upgradeList = {};
var bulletList = {};

Slime = function(id, x, y, width, height) {
	var self = Actor('enemy', id, x, y, width, height, Img.slime, 3, 0.5, 0.1);
	self.atkSpd = 0;
	self.bltImg = Img.bullet.magic
	var super_update = self.update
	self.update = function() {
		super_update();
		self.updateAim();
	}
	enemyList[id] = self;
}
randomlyGenerateSlime = function() {
	Slime(Math.random(), Math.random() * WIDTH, Math.random() * HEIGHT, 40, 40);
}
Goblin = function(id, x, y, width, height) {
	var self = Actor('enemy', id, x, y, width, height, Img.goblin, 7, 2, 3);
	self.atkSpd = 1;
	self.bltImg = Img.bullet.knife
	var super_update = self.update
	self.update = function() {
		super_update();
		self.updateAim();
	}
	enemyList[id] = self;
}
randomlyGenerateGoblin = function() {
	Goblin(Math.random(), Math.random() * WIDTH, Math.random() * HEIGHT, 60, 75);
}
Gooshroom = function(id, x, y, width, height) {
	var self = Actor('enemy', id, x, y, width, height, Img.gooshroom, 15, 2, 1);
	self.atkSpd = 5;
	self.bltImg = Img.bullet.goo
	var super_update = self.update
	self.update = function() {
		super_update();
		self.updateAim();
	}
	enemyList[id] = self
}
randomlyGenerateGooshroom = function() {
	Gooshroom(Math.random(), Math.random() * WIDTH, Math.random() * HEIGHT, 45, 35)
}
Tank = function(id, x, y, width, height) {
	var self = Actor('enemy', id, x, y, width, height, Img.tank, 50, 5, 15);
	self.atkSpd = 50;
	self.bltImg = Img.bullet.nrgSpawn
	var super_update = self.update
	self.update = function() {
		super_update();
		self.updateAim();
	}
	enemyList[id] = self
}
randomlyGenerateTank = function() {
	Tank(Math.random(), Math.random() * WIDTH, Math.random() * HEIGHT, 100, 150)
}

Upgrade = function(id, x, y, width, height, img, category) {
	var self = Entity('upgrade', id, x, y, width, height, img);
	self.category = category;
	upgradeList[id] = self;
}

randomlyGenerateUpgrade = function() {
	//Math.random() returns a number between 0 and 1
	var x = Math.random() * currentMap.width;
	var y = Math.random() * currentMap.height;
	var height = 32;
	var width = 32;
	var id = Math.random();

	if (Math.random() < 0.5) {
		var category = 'score';
		var img = Img.upgrade2;
	}
	else {
		var category = 'atkSpd';
		var img = Img.upgrade1;
	}

	Upgrade(id, x, y, width, height, img, category);
}

Bullet = function(id, x, y, spdX, spdY, width, height, combatType, bulletImage, atk) {
	var self = Entity('bullet', id, x, y, width, height, bulletImage);
	self.combatType = combatType;
	self.timer = 0;
	self.spdX = spdX;
	self.spdY = spdY;
	self.atk = atk

	self.updatePosition = function() {
		self.x += self.spdX;
		self.y += self.spdY;

		if (self.x < 0 || self.x > currentMap.width) {
			self.spdX = -self.spdX;
		}
		if (self.y < 0 || self.y > currentMap.height) {
			self.spdY = -self.spdY;
		}
	}
	bulletList[id] = self
}

generateBullet = function(actor, aimOverwrite) {
	//Math.random() returns a number between 0 and 1
	var x = actor.x - actor.width / 2;
	var y = actor.y - actor.height / 2;
	var height = 20;
	var width = 20;
	var id = Math.random();

	var angle;
	if (aimOverwrite !== undefined)
		angle = aimOverwrite;
	else angle = actor.aimAngle;

	var spdX = Math.cos(angle / 180 * Math.PI) * 5;
	var spdY = Math.sin(angle / 180 * Math.PI) * 5;
	Bullet(id, x, y, spdX, spdY, width, height, actor.type, actor.bltImg, actor.bltAtk);
}

testCollisionRectRect = function(rect1, rect2) {
	return rect1.x <= rect2.x + rect2.width && rect2.x <= rect1.x + rect1.width && rect1.y <= rect2.y + rect2.height && rect2.y <= rect1.y + rect1.height;
}
document.onclick = function(mouse) {
	player.performAttack(player.aimAngle);
}

document.oncontextmenu = function(mouse) {
	player.performSpecialAttack();
	mouse.preventDefault();
}

document.onmousemove = function(mouse) {
	var mouseX = mouse.clientX - document.getElementById('ctx').getBoundingClientRect().left;
	var mouseY = mouse.clientY - document.getElementById('ctx').getBoundingClientRect().top;

	mouseX -= WIDTH / 2;
	mouseY -= HEIGHT / 2;

	player.aimAngle = Math.atan2(mouseY, mouseX) / Math.PI * 180;
}

document.onkeydown = function(event) {
	if (event.keyCode === 68) //d
		player.pressingRight = true;
	else if (event.keyCode === 83) //s
		player.pressingDown = true;
	else if (event.keyCode === 65) //a
		player.pressingLeft = true;
	else if (event.keyCode === 87) // w
		player.pressingUp = true;
	else if (event.keyCode === 27) //esc
		paused = !paused
}

document.onkeyup = function(event) {
	if (event.keyCode === 68) //d
		player.pressingRight = false;
	else if (event.keyCode === 83) //s
		player.pressingDown = false;
	else if (event.keyCode === 65) //a
		player.pressingLeft = false;
	else if (event.keyCode === 87) // w
		player.pressingUp = false;
}

Maps = function(id, imgSrc, width, height) {
	var self = {
		id: id,
		image: new Image(),
		width: width,
		height: height,
	}
	self.image.src = imgSrc
	self.draw = function() {
		var x = WIDTH / 2 - player.x
		var y = HEIGHT / 2 - player.y
		ctx.drawImage(self.image, 0, 0, self.image.width, self.image.height, x, y, self.width, self.height)
	}
	return self;
}

currentMap = Maps("field", "images/grass.png", 2000, 1500)

startNewGame = function() {
	player.hp = 20;
	timeWhenGameStarted = Date.now();
	frameCount = 0;
	score = 0;
	enemyList = {};
	upgradeList = {};
	bulletList = {};
}

player = Player();
startNewGame();

update();