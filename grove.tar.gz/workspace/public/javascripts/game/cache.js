function cacheImages(array) {
    if (!cacheImages.list) {
        preloadImages.list = [];
    }
    var list = cacheImages.list;
    for (var i = 0; i < array.length; i++) {
        var img = new Image();
        img.onload = function() {
            var index = list.indexOf(this);
            if (index !== -1) {
                // remove image from the array once it's loaded
                // for memory consumption reasons
                list.splice(index, 1);
            }
        }
        list.push(img);
        img.src = array[i];
    }
}

cacheImages(["/images/mobs/Jermer.png", "/images/mobs/PurpleSmile.png", "/images/grass.png"]);