$(document).ready(function() {
    $('#settingsPanel').hide();
    $('#settingsBtn').click(function(e) {
        $('#settingsPanel').fadeIn(200);
    });
    $('.close').click(function(e) {
        $('#settingsPanel').fadeOut(200);
    });
    $('#quit').click(function(e) {
        window.close();
    });
});