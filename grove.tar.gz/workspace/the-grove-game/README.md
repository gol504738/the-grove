#### TO UPDATE TO HEROKU:
```
git init
git add .
git commit "commit name"
git push heroku master
```